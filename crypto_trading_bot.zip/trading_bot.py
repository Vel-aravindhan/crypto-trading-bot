import logging
from binance.client import Client
from binance.enums import *

# Setup logging
logging.basicConfig(filename='trading_bot.log', level=logging.INFO,
                    format='%(asctime)s:%(levelname)s:%(message)s')

class BasicBot:
    def __init__(self, api_key, api_secret, testnet=True):
        self.client = Client(api_key, api_secret)
        if testnet:
            self.client.FUTURES_URL = "https://testnet.binancefuture.com"

    def place_order(self, symbol, side, order_type, quantity, price=None):
        try:
            if order_type == 'MARKET':
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == 'BUY' else SIDE_SELL,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
            elif order_type == 'LIMIT':
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == 'BUY' else SIDE_SELL,
                    type=ORDER_TYPE_LIMIT,
                    quantity=quantity,
                    price=price,
                    timeInForce=TIME_IN_FORCE_GTC
                )
            else:
                logging.error("Invalid order type")
                return None

            logging.info(f"Order placed: {order}")
            return order

        except Exception as e:
            logging.error(f"Error placing order: {e}")
            return None

def get_user_input():
    symbol = input("Symbol (e.g., BTCUSDT): ").upper()
    side = input("Side (BUY or SELL): ").upper()
    order_type = input("Type (MARKET or LIMIT): ").upper()
    quantity = float(input("Quantity: "))
    price = None
    if order_type == 'LIMIT':
        price = float(input("Price: "))
    return symbol, side, order_type, quantity, price

if __name__ == "__main__":
    API_KEY = "your_api_key_here"
    API_SECRET = "your_api_secret_here"

    bot = BasicBot(API_KEY, API_SECRET)
    symbol, side, order_type, quantity, price = get_user_input()
    result = bot.place_order(symbol, side, order_type, quantity, price)
    print("Order Response:", result)
